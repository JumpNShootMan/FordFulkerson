import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-details-cliente',
  templateUrl: './details-cliente.component.html',
  styleUrls: ['./details-cliente.component.css']
})
export class DetailsClienteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
