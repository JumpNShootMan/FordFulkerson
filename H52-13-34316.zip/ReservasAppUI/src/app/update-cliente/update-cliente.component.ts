import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ClienteService } from '../cliente.service';
import { Cliente } from '../model/cliente';

@Component({
  selector: 'app-update-cliente',
  templateUrl: './update-cliente.component.html',
  styleUrls: ['./update-cliente.component.css']
})
export class UpdateClienteComponent implements OnInit {

  id: number;
  cliente: Cliente=new Cliente();

  constructor(private route: ActivatedRoute,
    private router: Router,
    private clienteService: ClienteService) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['id'];
    this.clienteService.getClienteById(this.id)
    .subscribe(datos => {
      console.log(datos)
      this.cliente = datos;
    }, error=> console.log(error));
  }

  actualizarCliente(){
    this.clienteService.updateCliente(this.id, this.cliente)
    .subscribe(data=>{
      console.log(data)
      this.router.navigate(['listar']);
    }, error=>console.log(error));
    this.cliente = new Cliente();
  }
}
