export class Cliente {
    id: number;
    nombres: string;
    apellidos: string;
    dni: string;
    direccion: string;
    telefono: string;
    email: string;
}