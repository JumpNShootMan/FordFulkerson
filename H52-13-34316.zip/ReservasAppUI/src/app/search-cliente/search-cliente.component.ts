import { Component, OnInit } from '@angular/core';
import { Cliente } from '../model/cliente';
import { ClienteService } from '../cliente.service';
import { ThrowStmt } from '@angular/compiler';

@Component({
  selector: 'app-search-cliente',
  templateUrl: './search-cliente.component.html',
  styleUrls: ['./search-cliente.component.css']
})
export class SearchClienteComponent implements OnInit {

  id: number;
  dni: string;
  candidato: Candidato;

  constructor(private clienteService: ClienteService) { }

  ngOnInit() {
  }

  searchClienteById(){
    this.clienteService.getCandidatoById(this.id)
    .subscribe(candidato=>this.candidato= candidato);
  }

  searchCandidatoByDNI(){
    this.clienteService.getCandidatoByDni(this.dni)
    .subscribe(candidato=>this.candidato= candidato);
  }

}
