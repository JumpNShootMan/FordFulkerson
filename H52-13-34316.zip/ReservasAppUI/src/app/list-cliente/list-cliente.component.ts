import { Component, OnInit } from '@angular/core';
import { Cliente } from '../model/cliente';
import { ClienteService } from '../cliente.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-cliente',
  templateUrl: './list-cliente.component.html',
  styleUrls: ['./list-cliente.component.css']
})
export class ListClienteComponent implements OnInit {

  apellidos: string='';
  clientes: Cliente[];

  constructor(private router: Router, private clienteService: ClienteService) { }

  ngOnInit() {
    this.loadData();
  }

  loadData(){
    this.clienteService.getClientesList()
    .subscribe(clientes=>this.clientes=clientes)
  }

  deleteCliente(cliente:Cliente){
    this.clienteService.deleteCliente(cliente.id)
    .subscribe(data =>{this.loadData();})
  }

  SearchCliente(){
    if(this.apellidos.length!=0){
      this.clienteService.getClienteByApellidos(this.apellidos)
      .subscribe(clientes=>this.clientes=clientes);
    }
    else{
      this.loadData();      
    }
  }

  updateCliente(cliente: Cliente){
    this.router.navigate(['actualizar', cliente.id]);
  }
}
