package edu.candidatos.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.reservas.entities.Candidato;
import com.reservas.repository.ICandidatoRepository;
import com.reservas.service.ICandidatoService;

@Service
@Transactional(readOnly=true)
public class CandidatoServiceImpl implements ICandidatoService{

	@Autowired
	private ICandidatoRepository candidatoRepository;
	
	@Override
	@Transactional
	public Candidato save(Candidato t)throws Exception {
		return candidatoRepository.save(t);
	}

	@Override
	@Transactional
	public void delete(Integer id) throws Exception{
		candidatoRepository.deleteById(id);	
	}

	@Override
	public Optional<Candidato> getById(Integer id) throws Exception{
		return candidatoRepository.findById(id);
	}

	@Override
	public List<Candidato> getAll()throws Exception {
		return candidatoRepository.findAll();
	}

	@Override
	public Candidato findByDni(String dni) throws Exception {
		return candidatoRepository.findByDni(dni);
	}

	@Override
	public List<Candidato> findByApellidos(String apellidos) throws Exception {
		return candidatoRepository.findByApellidos(apellidos);
	}

}
