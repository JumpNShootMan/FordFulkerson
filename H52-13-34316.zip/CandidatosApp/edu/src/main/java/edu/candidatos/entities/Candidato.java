package edu.candidatos.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

import lombok.Data;

@Entity
@Table(name="candidato")
@Data
@NamedQuery(name="Candidato.findByDni", 
query = "Select c from Candidato c Where c.dni=?1")
public class Candidato implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@Size(min=3, message = "El nombre debe tener mínimo 3 caracteres")
	@Column(name="nombres", nullable = false, length = 50)
	private String nombres;
	@Size(min=3, message = "Los apellidos deben tener mínimo 3 caracteres")
	@Column(name="apellidos", nullable = false, length = 50)
	private String apellidos;
	@Size(min=8, message = "El dni debe tener 8 caracteres")
	@Column(name="dni", nullable = false, length = 8)
	private String dni;
	@Column(name="numcand", nullable = true, length = 9)
	private String numcand;
	@Column(name="organizacion", nullable = true, length = 50)
	private String organizacion;
	@OneToMany(mappedBy = "candidato", cascade = CascadeType.ALL, 
			fetch = FetchType.LAZY)
	//private List<Reserva> reservas;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getNombres() {
		return nombres;
	}
	public void setNombres(String nombres) {
		this.nombres = nombres;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public String getNumCand() {
		return numcand;
	}
	public void setNumCand(String numcand) {
		this.numcand = numcand;
	}
	public String getOrganizacion() {
		return organizacion;
	}
	public void setOrganizacion(String organizacion) {
		this.organizacion = organizacion;
	}

}
