package edu.candidatos.controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import edu.candidatos.entities.Candidato;
import edu.candidatos.services.ICandidatoService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/api/candidatos")
@Api(tags="Candidato", value="Servicio Web RESTFull de Candidatos")
public class CandidatoController {
	
	@Autowired
	private ICandidatoService candidatoService;
	
	@GetMapping(produces=MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value="Listar Candidatos", notes="Servicio para listar todos los candidatos")
	@ApiResponses(value= {
			@ApiResponse(code=201, message="Candidatos encontrados"),
			@ApiResponse(code=404, message="Candidatos no encontrados")
	})	
	public ResponseEntity<List<Candidato>> findAll(){
		try {
			List<Candidato> candidatos = new ArrayList<>();
			candidatos = candidatoService.getAll();
			return new ResponseEntity<List<Candidato>>(candidatos, HttpStatus.OK);
		}catch(Exception e){
			return new ResponseEntity<List<Candidato>>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(value="/{id}", produces=MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value="Buscar Candidato por Id", notes="Servicio para buscar un candidato por Id")
	@ApiResponses(value= {
			@ApiResponse(code=201, message="Candidato encontrado"),
			@ApiResponse(code=404, message="Candidato no encontrado")
	})
	public ResponseEntity<Candidato> findById(@PathVariable("id") Integer id){
		try {
			Optional<Candidato> candidato= candidatoService.getById(id);
			if(!candidato.isPresent()) {
				return new ResponseEntity<Candidato>(HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<Candidato>(candidato.get(), HttpStatus.OK);
		}catch(Exception e){
			return new ResponseEntity<Candidato>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(value="/searchByDni/{dni}", produces=MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value="Buscar Candidato por Dni", notes="Servicio para buscar un candidato por Dni")
	@ApiResponses(value= {
			@ApiResponse(code=201, message="Candidato encontrado"),
			@ApiResponse(code=404, message="Candidato no encontrado")
	})
	public ResponseEntity<Candidato> findByDni(@PathVariable("dni") String dni){
		try {
			Candidato candidato= candidatoService.findByDni(dni);
			if(candidato==null) {
				return new ResponseEntity<Candidato>(HttpStatus.NOT_FOUND);
			}
			return new ResponseEntity<Candidato>(candidato, HttpStatus.OK);
		}catch(Exception e){
			return new ResponseEntity<Candidato>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@GetMapping(value="/searchByApellidos/{apellidos}", produces=MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value="Buscar Candidatos por Apellidos", notes="Servicio para buscar todos los candidatos por apellidos")
	@ApiResponses(value= {
			@ApiResponse(code=201, message="Candidatos encontrados"),
			@ApiResponse(code=404, message="Candidatos no encontrados")
	})	
	public ResponseEntity<List<Candidato>> findByApellidos(@PathVariable("apellidos") String apellidos){
		try {
			List<Candidato> candidatos = new ArrayList<>(); 
			candidatos = candidatoService.findByApellidos(apellidos);
			return new ResponseEntity<List<Candidato>>(candidatos, HttpStatus.OK);
		}catch(Exception e){
			return new ResponseEntity<List<Candidato>>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE,
			produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value="Crear Candidato", notes="Servicio para crear un nuevo candidato")
	@ApiResponses(value= {
			@ApiResponse(code=201, message="Candidato creado correctamente"),
			@ApiResponse(code=400, message="Solicitud inválida o candidato ya existe")
	})
	public ResponseEntity<Candidato> insertCandidato(@Valid @RequestBody Candidato candidato){
		try {
			Candidato candidatoNew = new Candidato();
			if(/*lista de candidatos*/.findAll() contains(candidatoNew.getDni())) {
				Exception = e;
				return error;
			}
			candidatoNew = candidatoService.save(candidato);
			URI location = ServletUriComponentsBuilder.fromCurrentRequest()
					.path("/{id}").buildAndExpand(candidatoNew.getId()).toUri();
			return ResponseEntity.created(location).build();
		}catch(Exception e) {
			return new ResponseEntity<Candidato>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PutMapping(value="/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, 
			produces = MediaType.APPLICATION_JSON_VALUE)	
	@ApiOperation(value="Actualizar Candidato", notes="Servicio para actualizar un candidato")
	@ApiResponses(value= {
			@ApiResponse(code=201, message="Candidato actualizado correctamente"),
			@ApiResponse(code=404, message="Candidato no encontrado")
	})
	public ResponseEntity<Candidato> updateCandidato(@PathVariable("id") Integer id,
			@Valid @RequestBody Candidato candidato){
		try {
			Optional<Candidato> cli= candidatoService.getById(id);
			if(!cli.isPresent()) {
				return new ResponseEntity<Candidato>(HttpStatus.NOT_FOUND);
			}
			candidato.setId(id);
			candidatoService.save(candidato);			
			return new ResponseEntity<Candidato>(candidato, HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<Candidato>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@DeleteMapping(value="/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
	@ApiOperation(value="Eliminar Candidato", notes="Servicio para eliminar un candidato")
	@ApiResponses(value= {
			@ApiResponse(code=201, message="Candidato eliminado correctamente"),
			@ApiResponse(code=404, message="Candidato no encontrado")
	})
	public ResponseEntity<Candidato> deleteCandidato(@PathVariable("id") Integer id){
		try {
			Optional<Candidato> candidato= candidatoService.getById(id);
			if(!candidato.isPresent()) {
				return new ResponseEntity<Candidato>(HttpStatus.NOT_FOUND);
			}
			candidatoService.delete(id);
			return new ResponseEntity<Candidato>(HttpStatus.OK);
		}catch(Exception e) {
			return new ResponseEntity<Candidato>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
