package edu.candidatos.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import edu.candidatos.entities.Candidato;

@Repository
public interface ICandidatoRepository extends JpaRepository<Candidato, Integer> {
	public Candidato findByDni(String dni);
	public List<Candidato> findByApellidos(String apellidos);	
}
