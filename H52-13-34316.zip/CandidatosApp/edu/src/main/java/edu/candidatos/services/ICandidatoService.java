package edu.candidatos.services;

import java.util.List;

import edu.candidatos.entities.Candidato;

public interface ICandidatoService extends CrudService<Candidato>{
	public Candidato findByDni(String dni) throws Exception;
	public List<Candidato> findByApellidos(String apellidos)throws Exception;	
}
