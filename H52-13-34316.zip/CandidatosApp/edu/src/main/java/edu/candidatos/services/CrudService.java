package edu.candidatos.services;

import java.util.List;
import java.util.Optional;

public interface CrudService<T> {
	T save(T t) throws Exception;
	void delete(Integer id) throws Exception;
	Optional<T> getById(Integer id) throws Exception;
	List<T> getAll() throws Exception;
}
